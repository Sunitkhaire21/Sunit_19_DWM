import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

# Create a figure and axis
fig, ax = plt.subplots(figsize=(10, 8))

# Function to draw block
def draw_block(ax, text, x, y, width=4, height=0.5, fontsize=12):
    block = FancyBboxPatch((x, y), width, height, boxstyle="round,pad=0.3", edgecolor="black", facecolor="lightgrey")
    ax.add_patch(block)
    ax.text(x + width / 2, y + height / 2, text, ha="center", va="center", fontsize=fontsize)

# Function to draw arrow between blocks (without touching the blocks)
def draw_arrow(ax, start, end):
    arrow = FancyArrowPatch(start, end, mutation_scale=15, color='blue', lw=2, arrowstyle='->')
    ax.add_patch(arrow)

# Block coordinates
blocks = [
    ("1. Load CSV File", (0, 5)),
    ("2. Data Preparation\n - Load Dataset\n - Split Data", (0, 4)),
    ("3. Model Training\n - Naive Bayes Classifier", (0, 3)),
    ("4. Model Evaluation\n - Accuracy Calculation\n - Confusion Matrix\n - Classification Report", (0, 2)),
    ("5. Visualization\n - Show Confusion Matrix", (0, 1))
]

# Draw blocks
for text, (x, y) in blocks:
    draw_block(ax, text, x, y)

# Draw arrows between blocks
for i in range(len(blocks) - 1):
    start = (blocks[i][1][0] + 2, blocks[i][1][1])  # Arrow starting point
    end = (blocks[i+1][1][0] + 2, blocks[i+1][1][1] + 0.5)  # Arrow ending point
    draw_arrow(ax, start, end)

# Annotations for input and output
ax.text(5, 5.5, "Input: CSV Dataset", color="red", fontsize=12)
ax.text(5, 1.5, "Output: Evaluation Metrics", color="red", fontsize=12)

# Adjust plot limits and remove axes
ax.set_xlim(-1, 7)
ax.set_ylim(0, 6)
ax.axis('off')

# Show the plot
plt.show()
