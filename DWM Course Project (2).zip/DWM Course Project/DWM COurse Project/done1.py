# Import necessary libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score

# Set style for seaborn
sns.set(style='whitegrid')

# Function to load and preprocess the dataset
def load_data():
    iris = load_iris()
    X = iris.data
    y = iris.target
    feature_names = iris.feature_names
    target_names = iris.target_names
    return X, y, feature_names, target_names

# Function to split the dataset
def split_data(X, y, test_size=0.2, random_state=42):
    return train_test_split(X, y, test_size=test_size, random_state=random_state)

# Function to create and train the Gaussian Naive Bayes model
def train_model(X_train, y_train):
    model = GaussianNB()
    model.fit(X_train, y_train)
    return model

# Function to evaluate the model
def evaluate_model(model, X_test, y_test, target_names):
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    conf_matrix = confusion_matrix(y_test, y_pred)
    class_report = classification_report(y_test, y_pred, target_names=target_names)
    
    return accuracy, conf_matrix, class_report

# Function to perform cross-validation
def cross_validate_model(model, X, y, cv=5):
    scores = cross_val_score(model, X, y, cv=cv)
    return scores.mean(), scores.std()

# Function to visualize the confusion matrix
def plot_confusion_matrix(conf_matrix, target_names):
    plt.figure(figsize=(8, 6))
    sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues',
                xticklabels=target_names, yticklabels=target_names)
    plt.ylabel('Actual')
    plt.xlabel('Predicted')
    plt.title('Confusion Matrix')
    plt.show()

# Function for hyperparameter tuning (if needed in more complex scenarios)
def hyperparameter_tuning(X_train, y_train):
    param_grid = {'var_smoothing': np.logspace(0,-9, num=100)}
    grid_search = GridSearchCV(GaussianNB(), param_grid, cv=5)
    grid_search.fit(X_train, y_train)
    return grid_search.best_estimator_

# Main function to execute the workflow
def main():
    # Load the data
    X, y, feature_names, target_names = load_data()
    
    # Split the data
    X_train, X_test, y_train, y_test = split_data(X, y)
    
    # Train the model
    model = train_model(X_train, y_train)
    
    # Evaluate the model
    accuracy, conf_matrix, class_report = evaluate_model(model, X_test, y_test, target_names)
    
    # Print evaluation metrics
    print(f'Accuracy: {accuracy * 100:.2f}%')
    print('Classification Report:')
    print(class_report)
    
    # Plot the confusion matrix
    plot_confusion_matrix(conf_matrix, target_names)
    
    # Perform cross-validation
    mean_cv_score, std_cv_score = cross_validate_model(model, X, y)
    print(f'Cross-Validation Accuracy: {mean_cv_score * 100:.2f}% ± {std_cv_score * 100:.2f}%')
    
    # Uncomment for hyperparameter tuning
    # best_model = hyperparameter_tuning(X_train, y_train)
    # accuracy, conf_matrix, class_report = evaluate_model(best_model, X_test, y_test, target_names)
    # print(f'Best Model Accuracy: {accuracy * 100:.2f}%')

if __name__ == "__main__":
    main()
