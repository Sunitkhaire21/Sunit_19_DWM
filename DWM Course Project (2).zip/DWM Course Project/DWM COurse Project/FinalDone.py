import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score
import seaborn as sns
from sklearn.datasets import load_iris
import tkinter as tk
from tkinter import filedialog, messagebox

# Set style for seaborn
sns.set(style='whitegrid')

# Function to train and evaluate the model
def train_and_evaluate(file_path):
    try:
        # Load the dataset
        df = pd.read_csv(file_path)
        
        # Assuming the last column is the target
        X = df.iloc[:, :-1].values
        y = df.iloc[:, -1].values
        
        # Splitting the dataset into training and testing sets
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        # Implementing the Naive Bayes Classifier
        model = GaussianNB()
        
        # Train the model
        model.fit(X_train, y_train)
        
        # Make predictions
        y_pred = model.predict(X_test)
        
        # Evaluate the model
        accuracy = accuracy_score(y_test, y_pred)
        conf_matrix = confusion_matrix(y_test, y_pred)
        class_report = classification_report(y_test, y_pred)

        # Display evaluation metrics
        messagebox.showinfo("Results", f'Accuracy: {accuracy * 100:.2f}%\n\nClassification Report:\n{class_report}')

        # Visualizing the Confusion Matrix
        plt.figure(figsize=(8, 6))
        sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', 
                    xticklabels=np.unique(y), yticklabels=np.unique(y))
        plt.ylabel('Actual')
        plt.xlabel('Predicted')
        plt.title('Confusion Matrix')
        plt.show()
        
    except Exception as e:
        messagebox.showerror("Error", str(e))

# Function to load the dataset file
def load_file():
    file_path = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv")])
    if file_path:
        train_and_evaluate(file_path)

# Setting up the GUI
root = tk.Tk()
root.title("Naive Bayes Classifier")

# Create a button to load the dataset
load_button = tk.Button(root, text="Load Dataset", command=load_file, padx=10, pady=5)
load_button.pack(pady=20)

# Run the application
root.geometry("300x100")
root.mainloop()
